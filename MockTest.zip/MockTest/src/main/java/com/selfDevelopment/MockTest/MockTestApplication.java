package com.selfDevelopment.MockTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MockTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(MockTestApplication.class, args);
	}

}
