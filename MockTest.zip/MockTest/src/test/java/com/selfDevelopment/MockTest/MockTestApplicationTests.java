package com.selfDevelopment.MockTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
